function go(file_name){
    window.open(file_name);
}
