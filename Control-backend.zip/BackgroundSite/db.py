from pymongo import MongoClient

client = MongoClient("localhost", 27017)

db = client.control_database

tasks = db.tasks
tasks.insert_many([
    {"task":"design", "state":"to-do"},
    {"task":"frontend","state":"in-progress"},
    {"task":"backend","state":"done"},
    {"task":"phuck", "state":"in-progress"}
 ])

 
tasks = db.user
tasks.insert_many([
    {}
])