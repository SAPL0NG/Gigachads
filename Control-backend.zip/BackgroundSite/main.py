from flask import Flask, request, redirect
import mydatabase
from jinja2 import FileSystemLoader, Environment
from pymongo import *
from bson.objectid import ObjectId


templateLoader = Environment(loader=FileSystemLoader(searchpath="./templates"))
tasks = []
name = []

app = Flask(__name__, static_folder="./static", static_url_path = "/static")

@app.route('/')
def start():
    template = templateLoader.get_template("info.html")
    return template.render() 


@app.route('/register') #Регистрация на сайте
def register_page():
    return templateLoader.get_template('registration.html').render()
    

@app.route('/registration' , methods=["POST", "GET"])
def regist():
    return redirect ("/registration/auth")


@app.route("/registration/auth", methods=["POST", "GET"])
def bac():
    mydatabase.insert_new_user(request.form.get('name'), request.form.get('last_name'),  request.form.get('email'),  request.form.get('birthday'),  request.form.get('qualification'),  request.form.get('password'),  request.form.get('repeat_password'))
    return redirect ("/")


@app.route("/index")  #Главная смтраица
def getTasks():
    template = templateLoader.get_template("index.html")
    mydatabase.get_all_documents()
    return template.render(tasks = tasks)


@app.route("/createTask", methods =["POST"]) #Таблица выпоонения
def createTask():
    tasks.append(request.form.get("task"))
    return redirect("/index")


@app.route("/deleteTask", methods =["POST"]) #Таблица удаления
def deleteTask():
    task = request.form.get('task')
    try:
        tasks.pop(int(task)-1)
    except:
        pass
    return redirect("/index")


 
@app.route('/login.html')  #Логин на сайт
def login():
    return templateLoader.get_template('login.html').render()


@app.route("/login") 
def login_page():
    mydatabase.insert_new_user(request.form.get("email"), request.form.get('password'))
    return redirect ("/")   


@app.route('/loginone', methods=['POST'])
def find():
    if mydatabase.find_email_and_pass(request.form.get("email"), request.form.get('password')):
        return redirect ("/home")
    else:
        return redirect ("/login.html")
       


@app.route('/home') #Переход на страницу 
def home():
    return templateLoader.get_template('index.html').render()


@app.route('/back')
def back():
    return redirect ('/home')


    
app.run(host = "0.0.0.0", port = 3000)