from asyncio import tasks
from django.shortcuts import redirect
from pymongo import MongoClient


client = MongoClient("localhost", 27017)
db = client.control_database

def get_all_documents():
    tasks = db.tasks
    tasks.find_one({"email": ""})
    tasks.find_one({"password": ""})
    for i in tasks.find():
        print(i)


def insert_new_task(task, state):
    tasks = db.tasks
    tasks.insert_one({"task":task, "state": state})


def insert_new_user(name, last_name, email, birthday, qualification, password, repeat_password):
    tasks = db.user
    tasks.insert_one({"name":name, "last_name":last_name, "email": email, "birthday": birthday, "qualification": qualification , "password": password, "repeat_password": repeat_password})


def find_email_and_pass(email, password):
    user = db.user
    user_data = user.find_one({"email": email, "password": password})
    num = user.count_documents({"email": email, "password": password})
    if num > 0:
        return (True)
    else:
        return (False)
    