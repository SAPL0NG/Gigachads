from pymongo import MongoClient

client = MongoClient("localhost", 27017)
db = client.control_database


def get_all_documents():
    tasks = db.tasks
    for i in tasks.find():
        print(i)


def insert_new_task(task, state):
    tasks = db.tasks
    tasks.insert_one({"task":task, "state": state})
