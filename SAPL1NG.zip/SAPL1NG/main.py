from flask import Flask, request, redirect

from jinja2 import FileSystemLoader, Environment

templateLoader = Environment(loader=FileSystemLoader(searchpath="./templates"))
tasks = []
app = Flask(__name__, static_folder="./static", static_url_path = "/static")


@app.route("/")
def getTasks():
    template = templateLoader.get_template("info.html")
    return template.render(tasks = tasks)


@app.route("/createTask", methods =["POST"])
def createTask():
    tasks.append(request.form.get("task"))
    return redirect("/")


@app.route("/deleteTask", methods =["POST"])
def deleteTask():
    task = request.form.get('task')
    try:
        tasks.pop(int(task)-1)
    except:
        pass
    return redirect("/")



app.run(host = "0.0.0.0", port = 3000)