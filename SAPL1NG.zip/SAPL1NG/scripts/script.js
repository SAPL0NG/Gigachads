function pageNotFound(){
    if(console.error()=="404"){
        open("/templates/error404.html")
    }
}
